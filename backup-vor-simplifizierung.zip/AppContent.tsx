import React, { useState, Suspense } from 'react';
import { useAuth } from './contexts/AuthContext';
import { AuthModal } from './components/AuthModal';
import { PaymentModal } from './components/PaymentModal';
import { ShareModal } from './components/ShareModal';
import { Layout } from './components/Layout';
import { AdAnalysis } from './types';
import { generatePDFReport, generateBulkPDFReport, generateKleinanzeigenZIP, generateKleinanzeigePDF } from './utils/pdfGenerator';
import { NotificationContainer } from './components/NotificationContainer';
import { FeedbackModal } from './components/FeedbackModal';
import { useNotifications } from './contexts/NotificationContext';
import Loading from './components/Loading';

// Lazy loading der View-Komponenten für bessere Performance
const DashboardView = React.lazy(() => import('./components/DashboardView'));
const ScannerView = React.lazy(() => import('./components/ScannerView'));
const HistoryView = React.lazy(() => import('./components/HistoryView'));
const SettingsView = React.lazy(() => import('./components/SettingsView'));
const AdView = React.lazy(() => import('./components/AdView'));

const AppContent: React.FC = () => {
  const { user, loading } = useAuth();
  const { addNotification, sendPushNotification } = useNotifications();
  const [currentView, setCurrentView] = useState('dashboard');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [showAdView, setShowAdView] = useState(false);
  const [selectedResult, setSelectedResult] = useState<AdAnalysis | null>(null);
  const [selectedAdImage, setSelectedAdImage] = useState<string>('');
  const [analysisResults, setAnalysisResults] = useState<AdAnalysis[]>([]);

  const handleAnalysisComplete = (result: AdAnalysis, image: string) => {
    setAnalysisResults(prev => [result, ...prev]);
    console.log('Analysis completed:', result);

    // Show success notification
    addNotification({
      type: 'success',
      title: 'Analyse erfolgreich!',
      message: `${result.title} wurde erfolgreich analysiert.`,
      action: {
        label: 'Ansehen',
        onClick: () => setCurrentView('history')
      }
    });

    // Send push notification if permission granted
    sendPushNotification('Werkaholic AI', {
      body: `${result.title} - ${result.price_estimate}`,
      icon: '/favicon.ico',
      badge: '/favicon.ico'
    });
  };

  const handleCancel = () => {
    setCurrentView('dashboard');
  };

  const clearResults = () => {
    setAnalysisResults([]);
  };

  const openShareModal = (result: AdAnalysis) => {
    setSelectedResult(result);
    setShowShareModal(true);
  };

  const handleShare = async (result: AdAnalysis, platform?: string) => {
    const shareText = `Werkaholic AI Analyse: ${result.title}\nGeschätzter Wert: ${result.price_estimate}\nZustand: ${result.condition}\nKategorie: ${result.category}\n\nAnalysiert mit KI: ${result.description}`;
    const shareUrl = window.location.href;

    if (platform) {
      // Platform-specific sharing
      const encodedText = encodeURIComponent(shareText);
      const encodedUrl = encodeURIComponent(shareUrl);

      let shareLink = '';

      switch (platform) {
        case 'facebook':
          shareLink = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodedText}`;
          break;
        case 'twitter':
          shareLink = `https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`;
          break;
        case 'whatsapp':
          shareLink = `https://wa.me/?text=${encodedText}%20${encodedUrl}`;
          break;
        case 'email':
          shareLink = `mailto:?subject=Werkaholic%20AI%20-%20${encodeURIComponent(result.title)}&body=${encodedText}`;
          break;
        default:
          break;
      }

      if (shareLink) {
        window.open(shareLink, '_blank', 'width=600,height=400');
        setShowShareModal(false);
        return;
      }
    }

    // Native share API or fallback
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Werkaholic AI - ${result.title}`,
          text: shareText,
          url: shareUrl,
        });
        setShowShareModal(false);
      } catch (error) {
        // Fallback to clipboard
        await navigator.clipboard.writeText(shareText);
        addNotification({ type: 'info', title: 'In Zwischenablage kopiert', message: 'Ergebnis wurde in die Zwischenablage kopiert.' });
        setShowShareModal(false);
      }
    } else {
      // Fallback: copy to clipboard
      await navigator.clipboard.writeText(shareText);
      addNotification({ type: 'info', title: 'In Zwischenablage kopiert', message: 'Ergebnis wurde in die Zwischenablage kopiert.' });
      setShowShareModal(false);
    }
  };

  const downloadResult = async (result: AdAnalysis) => {
    try {
      await generatePDFReport(result);
    } catch (error) {
      console.error('Error generating PDF:', error);
      addNotification({ type: 'error', title: 'PDF-Fehler', message: 'Das PDF konnte nicht erstellt werden.' });
    }
  };

  const downloadBulkReport = async () => {
    if (analysisResults.length === 0) return;

    try {
      await generateBulkPDFReport(analysisResults);
    } catch (error) {
      console.error('Error generating bulk PDF:', error);
      addNotification({ type: 'error', title: 'PDF-Fehler', message: 'Der Sammelbericht konnte nicht erstellt werden.' });
    }
  };

  const downloadKleinanzeigenZIP = async () => {
    if (analysisResults.length === 0) return;

    try {
      await generateKleinanzeigenZIP(analysisResults);
      addNotification({ type: 'success', title: 'ZIP erstellt', message: 'Kleinanzeigen-ZIP wurde heruntergeladen.' });
    } catch (error) {
      console.error('Error generating Kleinanzeigen ZIP:', error);
      addNotification({ type: 'error', title: 'ZIP-Fehler', message: 'Die Kleinanzeigen-ZIP konnte nicht erstellt werden.' });
    }
  };

  const openKleinanzeige = async (result: AdAnalysis) => {
    try {
      const pdfBlob = await generateKleinanzeigePDF(result);
      const url = URL.createObjectURL(pdfBlob);
      window.open(url, '_blank');
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error opening Kleinanzeige PDF:', error);
      addNotification({ type: 'error', title: 'PDF-Fehler', message: 'Die Kleinanzeige konnte nicht geöffnet werden.' });
    }
  };

  const openAdView = (result: AdAnalysis) => {
    console.log('🔄 Open AdView called for result:', result.title);
    setSelectedResult(result);
    // For now, we'll use a placeholder image. In a real app, you'd get this from the scan data
    setSelectedAdImage(''); // TODO: Get actual image from scan data
    setShowAdView(true);
    console.log('✅ AdView opened');
  };

  const closeAdView = () => {
    setShowAdView(false);
    setSelectedResult(null);
    setSelectedAdImage('');
  };

  const saveAdResult = (updatedResult: AdAnalysis) => {
    // Update the result in the analysisResults array
    setAnalysisResults(prev =>
      prev.map(result =>
        result.title === updatedResult.title ? updatedResult : result
      )
    );
  };

  if (loading) {
    return <Loading message="Authentifizierung läuft..." />;
  }

  if (!user) {
    return (
      <>
        <div className="min-h-screen bg-slate-900 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-white mb-8">Werkaholic AI</h1>
            <p className="text-slate-400 mb-8">KI-gestützte Werbeanalyse</p>
            <button
              onClick={() => setShowAuthModal(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-xl font-bold text-lg"
            >
              Jetzt starten
            </button>
          </div>
        </div>
        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
        />
      </>
    );
  }

  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <Suspense fallback={<Loading message="Dashboard wird geladen..." />}>
            <DashboardView
              analysisResults={analysisResults}
              onDownloadBulkReport={downloadBulkReport}
              onDownloadKleinanzeigenZIP={downloadKleinanzeigenZIP}
              onAnalysisComplete={handleAnalysisComplete}
              onOpenKleinanzeige={openKleinanzeige}
            />
          </Suspense>
        );
      case 'scanner':
        return (
          <Suspense fallback={<Loading message="Scanner wird vorbereitet..." />}>
            <ScannerView 
              onAnalysisComplete={handleAnalysisComplete} 
              onCancel={handleCancel} 
            />
          </Suspense>
        );
      case 'history':
        return (
          <Suspense fallback={<Loading message="Verlauf wird geladen..." />}>
            <HistoryView
              analysisResults={analysisResults}
              onClearResults={clearResults}
              onShareResult={openShareModal}
              onDownloadResult={downloadResult}
              onOpenResult={openAdView}
            />
          </Suspense>
        );
      case 'settings':
        return (
          <Suspense fallback={<Loading message="Einstellungen werden geladen..." />}>
            <SettingsView onFeedbackClick={() => setShowFeedbackModal(true)} />
          </Suspense>
        );
      default:
        return (
          <Suspense fallback={<Loading message="Dashboard wird geladen..." />}>
            <DashboardView 
              analysisResults={analysisResults} 
              onDownloadBulkReport={downloadBulkReport} 
              onAnalysisComplete={handleAnalysisComplete}
            />
          </Suspense>
        );
    }
  };

  return (
    <>
      <Layout currentView={currentView} onViewChange={setCurrentView}>
        {renderCurrentView()}

        <PaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          onSuccess={() => {
            console.log('Payment successful!');
          }}
        />

        {selectedResult && (
          <ShareModal
            isOpen={showShareModal}
            onClose={() => setShowShareModal(false)}
            result={selectedResult}
            onShare={handleShare}
          />
        )}

        <FeedbackModal
          isOpen={showFeedbackModal}
          onClose={() => setShowFeedbackModal(false)}
        />

        <NotificationContainer />
      </Layout>

      {/* AdView - Full screen overlay */}
      {showAdView && selectedResult && (
        <Suspense fallback={<Loading message="Inserat wird geladen..." />}>
          <AdView
            result={selectedResult}
            imageData={selectedAdImage}
            onBack={closeAdView}
            onSave={saveAdResult}
          />
        </Suspense>
      )}

      {/* Debug: Show AdView trigger button if no results exist */}
      {analysisResults.length === 0 && (
        <div style={{
          position: 'fixed',
          bottom: '20px',
          right: '20px',
          zIndex: 9999
        }}>
          <button
            onClick={() => {
              // Create a test result for debugging
              const testResult = {
                item_detected: true,
                title: "Test Inserat",
                price_estimate: "99€",
                condition: "Gut",
                category: "Elektronik",
                description: "Dies ist ein Test-Inserat für Debugging-Zwecke.",
                keywords: ["test", "debug", "inserat"],
                reasoning: "Test-Daten für Debugging"
              };
              setSelectedResult(testResult);
              setSelectedAdImage('');
              setShowAdView(true);
            }}
            style={{
              padding: '10px 20px',
              backgroundColor: '#3b82f6',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer'
            }}
          >
            🐛 Debug: AdView öffnen
          </button>
        </div>
      )}
    </>
  );
};

export default AppContent;