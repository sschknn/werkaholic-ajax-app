import React, { useState, useEffect, useMemo } from 'react';
import { LayoutDashboard, Package, BarChart3, History, Zap, Moon, Sun, Archive, ShoppingBag, Search, ChevronRight, Filter, DollarSign, PieChart as PieIcon, ArrowUpRight } from 'lucide-react';
import Scanner from './components/Scanner';
import ResultView from './components/ResultView';
import { ViewState, AdAnalysis, HistoryItem } from './types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area, CartesianGrid } from 'recharts';

// --- Helper Functions for Analytics ---

const parsePrice = (priceStr: string): number => {
  // Extracts the average price from a range string like "150€ - 200€" or "50 €"
  try {
    const numbers = priceStr.match(/(\d+[.,]?\d*)/g);
    if (!numbers) return 0;
    
    const parsedNumbers = numbers.map(n => parseFloat(n.replace(',', '.')));
    
    if (parsedNumbers.length === 0) return 0;
    if (parsedNumbers.length === 1) return parsedNumbers[0];
    
    // Calculate average of range
    const sum = parsedNumbers.reduce((a, b) => a + b, 0);
    return sum / parsedNumbers.length;
  } catch (e) {
    return 0;
  }
};

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>(ViewState.DASHBOARD);
  // Track previous view to return correctly from Results
  const [previousView, setPreviousView] = useState<ViewState>(ViewState.DASHBOARD);
  
  const [currentResult, setCurrentResult] = useState<AdAnalysis | null>(null);
  const [currentImages, setCurrentImages] = useState<string[]>([]);
  const [currentId, setCurrentId] = useState<string | null>(null);
  
  // Search state for Inventory
  const [searchTerm, setSearchTerm] = useState("");

  // Dark Mode State initialization
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem('werkaholic_theme');
    if (saved) {
      return saved === 'dark';
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  // Apply Dark Mode class and persist
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('werkaholic_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('werkaholic_theme', 'light');
    }
  }, [darkMode]);

  const toggleDarkMode = () => setDarkMode(!darkMode);

  // Initialize history from localStorage
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('werkaholic_history');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      console.error("Failed to load history", e);
      return [];
    }
  });

  // Persist history whenever it changes
  useEffect(() => {
    localStorage.setItem('werkaholic_history', JSON.stringify(history));
  }, [history]);

  // --- Derived Data for Analytics ---
  
  const analyticsData = useMemo(() => {
    const totalItems = history.length;
    const totalValue = history.reduce((acc, item) => acc + parsePrice(item.analysis.price_estimate), 0);
    const averageValue = totalItems > 0 ? totalValue / totalItems : 0;

    // Category Distribution
    const categoryCount: Record<string, number> = {};
    history.forEach(item => {
      const cat = item.analysis.category || "Sonstige";
      categoryCount[cat] = (categoryCount[cat] || 0) + 1;
    });

    const categoryData = Object.keys(categoryCount).map(key => ({
      name: key,
      value: categoryCount[key]
    })).sort((a, b) => b.value - a.value);

    // Recent Revenue Trend (Mock logic mapped to real dates would be complex, using simple distribution here)
    const priceDistribution = history.map((item, index) => ({
      name: `Item ${index + 1}`,
      value: parsePrice(item.analysis.price_estimate)
    })).slice(0, 20); // Last 20 items

    return { totalItems, totalValue, averageValue, categoryData, priceDistribution };
  }, [history]);

  // --- Handlers ---

  const handleAnalysisComplete = (result: AdAnalysis, image: string) => {
    const newId = Date.now().toString();
    const newItem: HistoryItem = {
      id: newId,
      image,
      additionalImages: [],
      date: new Date().toLocaleDateString('de-DE', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric' }),
      analysis: result
    };
    
    setHistory(prev => [newItem, ...prev]);
    // Stay on dashboard but prep data
    setCurrentResult(result);
    setCurrentImages([image]);
    setCurrentId(newId);
  };

  const handleUpdateResult = (updatedAnalysis: AdAnalysis, updatedImages?: string[]) => {
    if (!currentId) return;

    setCurrentResult(updatedAnalysis);
    if (updatedImages) setCurrentImages(updatedImages);

    setHistory(prev => prev.map(item => {
      if (item.id === currentId) {
        return {
          ...item,
          analysis: updatedAnalysis,
          image: updatedImages ? updatedImages[0] : item.image,
          additionalImages: updatedImages ? updatedImages.slice(1) : item.additionalImages
        };
      }
      return item;
    }));
  };

  const handleArchiveItem = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if(window.confirm("Möchtest du dieses Produkt aus dem Bestand löschen?")) {
      setHistory(prev => prev.filter(item => item.id !== id));
      if (currentId === id) {
        setView(previousView);
        setCurrentResult(null);
        setCurrentId(null);
      }
    }
  };

  const handleOpenItem = (item: HistoryItem) => {
    setCurrentResult(item.analysis);
    const allImages = [item.image, ...(item.additionalImages || [])];
    setCurrentImages(allImages);
    setCurrentId(item.id);
    setPreviousView(view); // Remember where we came from
    setView(ViewState.RESULTS);
  };

  // --- Render Views ---

  const renderSidebar = () => (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-64 flex-col bg-white dark:bg-slate-900 border-r dark:border-slate-800 h-screen sticky top-0 transition-colors z-40">
        <div className="p-6">
          <div className="flex items-center gap-2 cursor-pointer mb-8">
            <div className="bg-blue-600 rounded-lg p-1.5">
               <Zap className="w-5 h-5 text-white" fill="currentColor" />
            </div>
            <span className="font-bold text-xl tracking-tight text-slate-900 dark:text-white">
              Werkaholic <span className="text-blue-600">AI</span>
            </span>
          </div>
          
          <nav className="space-y-2">
            {[
              { id: ViewState.DASHBOARD, icon: LayoutDashboard, label: 'Dashboard' },
              { id: ViewState.INVENTORY, icon: Package, label: 'Warenbestand' },
              { id: ViewState.ANALYTICS, icon: BarChart3, label: 'Auswertung' },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setView(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${
                  view === item.id 
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30' 
                    : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <item.icon className="w-5 h-5" />
                {item.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="mt-auto p-6 border-t dark:border-slate-800">
           <div className="flex items-center justify-between bg-slate-50 dark:bg-slate-800 p-3 rounded-xl">
              <div className="flex items-center gap-3">
                 <div className="w-8 h-8 bg-blue-100 dark:bg-slate-700 rounded-full flex items-center justify-center text-blue-600 dark:text-white text-xs font-bold">
                    MA
                 </div>
                 <div className="text-sm">
                    <p className="font-bold text-slate-900 dark:text-white">Pro Account</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Max Mustermann</p>
                 </div>
              </div>
              <button onClick={toggleDarkMode} className="text-slate-400 hover:text-slate-900 dark:hover:text-white">
                 {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>
           </div>
        </div>
      </aside>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 border-t dark:border-slate-800 flex justify-around p-3 z-50 shadow-[0_-5px_20px_-5px_rgba(0,0,0,0.1)]">
        {[
          { id: ViewState.DASHBOARD, icon: LayoutDashboard, label: 'Scan' },
          { id: ViewState.INVENTORY, icon: Package, label: 'Bestand' },
          { id: ViewState.ANALYTICS, icon: BarChart3, label: 'Daten' },
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id)}
            className={`flex flex-col items-center gap-1 text-xs font-medium transition-colors ${
              view === item.id ? 'text-blue-600' : 'text-slate-400 dark:text-slate-500'
            }`}
          >
            <item.icon className={`w-6 h-6 ${view === item.id ? 'fill-current' : ''}`} />
            {item.label}
          </button>
        ))}
      </div>
    </>
  );

  const renderDashboard = () => (
    <div className="p-4 md:p-8 space-y-6 animate-fade-in pb-24 md:pb-12 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-2 md:hidden">
         <div className="flex items-center gap-2">
            <div className="bg-blue-600 rounded-lg p-1">
               <Zap className="w-4 h-4 text-white" fill="currentColor" />
            </div>
            <span className="font-bold text-lg text-slate-900 dark:text-white">Werkaholic AI</span>
         </div>
         <button onClick={toggleDarkMode} className="p-2 text-slate-500 dark:text-slate-400">
             {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
         </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-auto lg:h-[600px]">
         {/* Scanner */}
         <div className="lg:col-span-2 h-[500px] lg:h-full rounded-3xl shadow-xl overflow-hidden bg-slate-900 border border-slate-800 relative ring-1 ring-slate-900/5">
            <Scanner 
                onAnalysisComplete={handleAnalysisComplete} 
                onCancel={() => {}} 
                isEmbedded={true}
            />
         </div>

         {/* Recent Items Sidebar in Dashboard */}
         <div className="lg:col-span-1 h-[400px] lg:h-full bg-white dark:bg-slate-800 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700/50 flex flex-col overflow-hidden">
            <div className="p-5 border-b dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-900/50">
               <h3 className="font-bold text-slate-800 dark:text-white flex items-center gap-2">
                 <History className="w-5 h-5 text-blue-600" />
                 Schnellzugriff
               </h3>
               <button onClick={() => setView(ViewState.INVENTORY)} className="text-xs font-medium text-blue-600 hover:underline">
                 Alle anzeigen
               </button>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-2 custom-scrollbar">
               {history.slice(0, 5).map(item => (
                   <div key={item.id} onClick={() => handleOpenItem(item)} className="flex items-center gap-3 p-2 hover:bg-slate-50 dark:hover:bg-slate-700/50 rounded-xl cursor-pointer transition-colors border border-transparent hover:border-slate-100 dark:hover:border-slate-700">
                      <img src={item.image} className="w-12 h-12 rounded-lg object-cover bg-slate-200" />
                      <div className="flex-1 min-w-0">
                         <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">{item.analysis.title}</p>
                         <p className="text-xs text-green-600 dark:text-green-400 font-bold">{item.analysis.price_estimate}</p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-300" />
                   </div>
               ))}
               {history.length === 0 && (
                 <div className="text-center p-8 text-slate-400 text-sm">Keine Scans vorhanden.</div>
               )}
            </div>
         </div>
      </div>
    </div>
  );

  const renderInventory = () => {
    const filteredHistory = history.filter(item => 
      item.analysis.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.analysis.category.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
      <div className="p-4 md:p-8 space-y-6 animate-fade-in pb-24 md:pb-12 max-w-7xl mx-auto h-full flex flex-col">
         <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Package className="w-6 h-6 text-blue-600" />
                Warenbestand
              </h1>
              <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
                Verwalte deine {history.length} erfassten Produkte
              </p>
            </div>
            
            <div className="flex gap-2 w-full md:w-auto">
               <div className="relative flex-1 md:w-64">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="text" 
                    placeholder="Suchen..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white"
                  />
               </div>
               <button className="p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-500 hover:text-blue-600">
                  <Filter className="w-5 h-5" />
               </button>
            </div>
         </div>

         {/* Inventory List / Grid */}
         <div className="flex-1 overflow-y-auto bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700/50">
            {filteredHistory.length > 0 ? (
              <div className="divide-y divide-slate-100 dark:divide-slate-700">
                 {filteredHistory.map((item) => (
                   <div key={item.id} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors flex items-center gap-4 group">
                      <div className="w-16 h-16 md:w-20 md:h-20 shrink-0 rounded-xl overflow-hidden bg-slate-100 relative">
                         <img src={item.image} className="w-full h-full object-cover" />
                         {item.additionalImages && item.additionalImages.length > 0 && (
                            <div className="absolute bottom-0 right-0 bg-black/50 text-white text-[10px] px-1.5 py-0.5 rounded-tl-lg backdrop-blur-sm">
                              +{item.additionalImages.length}
                            </div>
                         )}
                      </div>
                      
                      <div className="flex-1 min-w-0 grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4 items-center">
                         <div className="md:col-span-2">
                            <h3 className="font-bold text-slate-900 dark:text-white truncate text-base">{item.analysis.title}</h3>
                            <div className="flex items-center gap-2 mt-1">
                               <span className="text-xs bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-full">
                                 {item.analysis.category}
                               </span>
                               <span className="text-xs text-slate-400">{item.date}</span>
                            </div>
                         </div>
                         <div className="flex items-center justify-between md:justify-end gap-4">
                            <div className="text-right">
                               <p className="font-black text-green-600 dark:text-green-400">{item.analysis.price_estimate}</p>
                               <p className="text-xs text-slate-400">{item.analysis.condition}</p>
                            </div>
                         </div>
                      </div>

                      <div className="flex items-center gap-2 md:opacity-0 group-hover:opacity-100 transition-opacity">
                         <button onClick={() => handleOpenItem(item)} className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg" title="Details">
                            <ArrowUpRight className="w-5 h-5" />
                         </button>
                         <button onClick={(e) => handleArchiveItem(e, item.id)} className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg" title="Löschen">
                            <Archive className="w-5 h-5" />
                         </button>
                      </div>
                   </div>
                 ))}
              </div>
            ) : (
              <div className="h-64 flex flex-col items-center justify-center text-slate-400">
                 <Package className="w-12 h-12 mb-4 opacity-20" />
                 <p>Keine Produkte gefunden.</p>
              </div>
            )}
         </div>
      </div>
    );
  };

  const renderAnalytics = () => (
    <div className="p-4 md:p-8 space-y-6 animate-fade-in pb-24 md:pb-12 max-w-7xl mx-auto">
       <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BarChart3 className="w-6 h-6 text-blue-600" />
              Auswertung
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
               Analyse deines Bestands und Potenzials
            </p>
          </div>
       </div>

       {/* KPI Cards */}
       <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white p-6 rounded-2xl shadow-lg shadow-blue-500/20 relative overflow-hidden">
             <div className="relative z-10">
               <p className="text-blue-100 text-sm font-medium mb-1">Gesamtwert (Geschätzt)</p>
               <h2 className="text-4xl font-black">{analyticsData.totalValue.toLocaleString('de-DE', {style: 'currency', currency: 'EUR'})}</h2>
               <p className="text-blue-200 text-xs mt-2 flex items-center gap-1">
                 <ArrowUpRight className="w-3 h-3" /> Basierend auf KI-Schätzungen
               </p>
             </div>
             <DollarSign className="absolute right-[-20px] bottom-[-20px] w-32 h-32 text-white/10 rotate-12" />
          </div>

          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700/50 flex flex-col justify-center">
             <div className="flex justify-between items-start">
                <div>
                   <p className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase tracking-wider mb-2">Erfasste Produkte</p>
                   <h2 className="text-4xl font-black text-slate-900 dark:text-white">{analyticsData.totalItems}</h2>
                </div>
                <div className="p-3 bg-indigo-50 dark:bg-indigo-900/30 rounded-xl text-indigo-600 dark:text-indigo-400">
                   <Package className="w-6 h-6" />
                </div>
             </div>
          </div>

          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700/50 flex flex-col justify-center">
             <div className="flex justify-between items-start">
                <div>
                   <p className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase tracking-wider mb-2">Durchschnittswert</p>
                   <h2 className="text-4xl font-black text-slate-900 dark:text-white">{analyticsData.averageValue.toLocaleString('de-DE', {style: 'currency', currency: 'EUR'})}</h2>
                </div>
                <div className="p-3 bg-emerald-50 dark:bg-emerald-900/30 rounded-xl text-emerald-600 dark:text-emerald-400">
                   <TrendingUpIcon className="w-6 h-6" />
                </div>
             </div>
          </div>
       </div>

       {/* Charts Row */}
       <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Category Distribution */}
          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700/50">
             <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-6">Kategorien</h3>
             <div className="h-64">
               <ResponsiveContainer width="100%" height="100%">
                 <PieChart>
                    <Pie
                      data={analyticsData.categoryData}
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {analyticsData.categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'][index % 5]} />
                      ))}
                    </Pie>
                    <Tooltip 
                       contentStyle={{backgroundColor: darkMode ? '#1e293b' : '#fff', borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px rgba(0,0,0,0.1)'}}
                       itemStyle={{color: darkMode ? '#fff' : '#000'}}
                    />
                 </PieChart>
               </ResponsiveContainer>
             </div>
             <div className="flex flex-wrap gap-2 justify-center mt-4">
                {analyticsData.categoryData.slice(0, 5).map((entry, index) => (
                   <div key={index} className="flex items-center gap-1 text-xs text-slate-600 dark:text-slate-400">
                      <div className="w-2 h-2 rounded-full" style={{backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'][index % 5]}}></div>
                      {entry.name} ({entry.value})
                   </div>
                ))}
             </div>
          </div>

          {/* Value Distribution Area Chart */}
          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700/50">
             <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-6">Werteverteilung (Letzte 20)</h3>
             <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                   <AreaChart data={analyticsData.priceDistribution}>
                      <defs>
                         <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                         </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={darkMode ? "#334155" : "#e2e8f0"} />
                      <XAxis hide dataKey="name" />
                      <YAxis 
                         axisLine={false} 
                         tickLine={false} 
                         tick={{fill: darkMode ? '#94a3b8' : '#64748b', fontSize: 12}} 
                         tickFormatter={(val) => `${val}€`}
                      />
                      <Tooltip 
                         contentStyle={{backgroundColor: darkMode ? '#1e293b' : '#fff', borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px rgba(0,0,0,0.1)'}}
                         itemStyle={{color: '#3b82f6'}}
                         formatter={(value: number) => [`${value.toFixed(2)}€`, 'Wert']}
                         labelStyle={{display: 'none'}}
                      />
                      <Area type="monotone" dataKey="value" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorValue)" />
                   </AreaChart>
                </ResponsiveContainer>
             </div>
          </div>
       </div>
    </div>
  );

  // --- Main Layout ---
  
  return (
    <div className={`min-h-screen bg-slate-50 dark:bg-slate-950 flex font-sans transition-colors duration-200`}>
      
      {/* Navigation Sidebar */}
      {renderSidebar()}

      {/* Main Content Area */}
      <main className="flex-1 overflow-auto w-full relative">
        {view === ViewState.DASHBOARD && renderDashboard()}
        
        {view === ViewState.INVENTORY && renderInventory()}

        {view === ViewState.ANALYTICS && renderAnalytics()}

        {/* Results view overlays everything or replaces content */}
        {view === ViewState.RESULTS && currentResult && currentImages.length > 0 && (
          <div className="absolute inset-0 bg-slate-50 dark:bg-slate-950 z-50 overflow-y-auto">
            <ResultView 
              result={currentResult} 
              images={currentImages} 
              onBack={() => setView(previousView)} 
              onSave={handleUpdateResult}
            />
          </div>
        )}
      </main>
    </div>
  );
};

// Add missing icon import
function TrendingUpIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg 
      {...props} 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
      <polyline points="17 6 23 6 23 12"></polyline>
    </svg>
  );
}

export default App;