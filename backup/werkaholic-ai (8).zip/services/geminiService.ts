import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AdAnalysis } from "../types";

// Initialize the client. API_KEY is assumed to be in the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const adAnalysisSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    item_detected: {
      type: Type.BOOLEAN,
      description: "Set to true if ANY sellable object is visible, even if it is small, a bit further away, or not perfectly centered. Only set false for completely empty scenes (floor, wall only).",
    },
    title: {
      type: Type.STRING,
      description: "A catchy, SEO-optimized title for a German sales platform (eBay Kleinanzeigen). If no item detected, return empty string.",
    },
    price_estimate: {
      type: Type.STRING,
      description: "Estimated price range in Euro (e.g. '50€ - 70€'). If no item detected, return empty string.",
    },
    condition: {
      type: Type.STRING,
      description: "Condition of the item (Neu, Sehr gut, Gut, Akzeptabel, Defekt).",
    },
    category: {
      type: Type.STRING,
      description: "The most fitting category for the item.",
    },
    description: {
      type: Type.STRING,
      description: "A professional, emotionally appealing sales description with bullet points.",
    },
    keywords: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of 5-10 relevant search tags.",
    },
    reasoning: {
      type: Type.STRING,
      description: "Short explanation of how the price was estimated based on visual condition.",
    },
  },
  required: ["item_detected", "title", "price_estimate", "condition", "description", "keywords", "category", "reasoning"],
};

export const analyzeImage = async (base64Image: string): Promise<AdAnalysis> => {
  try {
    // Remove header if present to get pure base64
    const cleanBase64 = base64Image.replace(/^data:image\/(png|jpg|jpeg|webp);base64,/, "");

    const model = "gemini-2.5-flash"; // Using 2.5 Flash for speed and vision capabilities

    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg", // Assuming JPEG for simplicity, works with most uploads
              data: cleanBase64,
            },
          },
          {
            text: `Du bist ein professioneller Verkaufs-Assistent für 'Werkaholic AI'. 
            Deine Aufgabe ist es, den Live-Kamera-Feed zu überwachen.
            
            Regeln für die Erkennung:
            1. Sei NICHT zu strikt. Erkenne Objekte auch, wenn sie etwas weiter weg liegen (mittlere Distanz) oder nicht das ganze Bild ausfüllen.
            2. Wenn ein Objekt erkennbar ist (Werkzeug, Deko, Elektronik, Kleidung, etc.), setze item_detected=true.
            3. Nur wenn wirklich NUR leerer Hintergrund (Boden, Tischplatte, Wand) zu sehen ist, setze item_detected=false.
            
            Fülle bei erkanntem Objekt alle Felder für ein eBay Kleinanzeigen Inserat aus.
            Antworte strikt als JSON.`,
          },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: adAnalysisSchema,
        temperature: 0.4, 
      },
    });

    const text = response.text;
    if (!text) throw new Error("Keine Antwort von Gemini erhalten.");

    return JSON.parse(text) as AdAnalysis;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};