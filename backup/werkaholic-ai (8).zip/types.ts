export interface AdAnalysis {
  item_detected: boolean; // True if a valid sellable item is found
  title: string;
  price_estimate: string; // e.g., "150€ - 200€"
  condition: string; // e.g., "Gut", "Neu", "Gebraucht"
  category: string;
  description: string;
  keywords: string[];
  reasoning: string; // Brief explanation of the valuation
}

export enum ViewState {
  DASHBOARD = 'DASHBOARD',
  INVENTORY = 'INVENTORY',
  ANALYTICS = 'ANALYTICS',
  SCANNER = 'SCANNER',
  RESULTS = 'RESULTS',
  HISTORY = 'HISTORY'
}

export interface HistoryItem {
  id: string;
  image: string; // The main thumbnail/hero image
  additionalImages?: string[]; // Array of extra images
  date: string;
  analysis: AdAnalysis;
}