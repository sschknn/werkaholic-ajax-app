import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Camera, Upload, X, Loader2, Sparkles, AlertCircle, RefreshCw, SwitchCamera, Image as ImageIcon, ScanLine, Radio, Check, CopyCheck, Power, Play, Pause } from 'lucide-react';
import { analyzeImage } from '../services/geminiService';
import { AdAnalysis } from '../types';

interface ScannerProps {
  onAnalysisComplete: (result: AdAnalysis, image: string) => void;
  onCancel: () => void;
  isEmbedded?: boolean;
}

const Scanner: React.FC<ScannerProps> = ({ onAnalysisComplete, onCancel, isEmbedded = false }) => {
  const [mode, setMode] = useState<'upload' | 'camera'>('camera');
  const [image, setImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastScannedResult, setLastScannedResult] = useState<AdAnalysis | null>(null);
  const [isDuplicateScan, setIsDuplicateScan] = useState(false);
  const [isQuotaExceeded, setIsQuotaExceeded] = useState(false);
  
  // New: Manual Pause/Standby state
  const [isPaused, setIsPaused] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const scanIntervalRef = useRef<number | null>(null);
  
  // Track last successful scan to prevent duplicates
  const lastSuccessRef = useRef<{title: string, time: number} | null>(null);

  // Stop camera when unmounting or switching modes
  useEffect(() => {
    return () => {
      stopCameraStream();
      if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
    };
  }, []);

  useEffect(() => {
    if (mode === 'camera' && !image && !isPaused && !isQuotaExceeded) {
      startCamera();
    } else {
      stopCameraStream();
      if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
    }
  }, [mode, image, isPaused, isQuotaExceeded]);

  const startCamera = async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraActive(true);
        // Start auto-scan loop after camera warms up
        startAutoScan();
      }
    } catch (err) {
      console.error("Camera Error:", err);
      setError("Kamera konnte nicht gestartet werden.");
      setMode('upload');
    }
  };

  const stopCameraStream = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setCameraActive(false);
    }
  };

  const togglePause = () => {
    if (isQuotaExceeded) {
        setIsQuotaExceeded(false);
        setIsPaused(false);
        setError(null);
    } else {
        setIsPaused(!isPaused);
    }
  };

  const startAutoScan = () => {
    if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
    if (isQuotaExceeded || isPaused) return; 

    setIsDuplicateScan(false);

    // Check every 18 seconds to avoid Rate Limits (429)
    scanIntervalRef.current = window.setInterval(() => {
      if (!isAnalyzing && mode === 'camera' && !image && !isPaused && !isQuotaExceeded) {
        attemptAutoCapture();
      }
    }, 18000); 
  };

  const handleScanSuccess = (result: AdAnalysis, dataUrl: string, isManual: boolean = false) => {
    if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
    
    // --- Duplicate Detection ---
    if (!isManual && lastSuccessRef.current) {
         const now = Date.now();
         const timeDiff = now - lastSuccessRef.current.time;
         
         if (timeDiff < 30000) { // 30 seconds cooldown
             const clean = (str: string) => str.toLowerCase().replace(/[^a-z0-9äöüß ]/g, '').trim();
             const lastTitle = clean(lastSuccessRef.current.title);
             const newTitle = clean(result.title);

             let isDuplicate = lastTitle === newTitle;

             if (!isDuplicate) {
                 const wordsLast = new Set(lastTitle.split(' ').filter(w => w.length > 2));
                 const wordsNew = new Set(newTitle.split(' ').filter(w => w.length > 2));
                 
                 if (wordsLast.size > 0 && wordsNew.size > 0) {
                     let matchCount = 0;
                     wordsLast.forEach(w => { if (wordsNew.has(w)) matchCount++; });
                     const overlap = matchCount / Math.max(wordsLast.size, wordsNew.size); 
                     if (overlap > 0.6) isDuplicate = true;
                 }
             }

             if (isDuplicate) {
                 console.log("Duplicate detected, skipping...");
                 setIsDuplicateScan(true);
                 setTimeout(() => {
                    setIsDuplicateScan(false);
                    startAutoScan(); 
                 }, 2000);
                 return;
             }
         }
    }

    lastSuccessRef.current = { title: result.title, time: Date.now() };
    setLastScannedResult(result);
    setImage(dataUrl); 
    
    const speakText = `Gefunden: ${result.title}. Geschätzter Wert: ${result.price_estimate}.`;
    speakResult(speakText);
    
    onAnalysisComplete(result, dataUrl);

    setTimeout(() => {
        setImage(null);
        setLastScannedResult(null);
        startAutoScan(); 
    }, 4000);
  };

  const attemptAutoCapture = useCallback(async () => {
    if (videoRef.current && canvasRef.current && !isAnalyzing && !isQuotaExceeded && !isPaused) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      if (video.readyState !== 4) return; 

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.7); 
        
        setIsAnalyzing(true);
        try {
          const result = await analyzeImage(dataUrl);
          
          if (result.item_detected) {
            handleScanSuccess(result, dataUrl, false);
          } else {
            console.log("No valid item detected, scanning continues...");
          }
        } catch (e: any) {
          console.error("Silent scan error", e);
          
          const errStr = JSON.stringify(e) + (e.message || "");
          if (errStr.includes("429") || errStr.includes("RESOURCE_EXHAUSTED")) {
             if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
             setIsQuotaExceeded(true);
             setIsPaused(true); // Force pause on error
             setError("⚠️ API-Limit erreicht. Scanner pausiert.");
             setIsAnalyzing(false);
             return;
          }
        } finally {
          setIsAnalyzing(false);
        }
      }
    }
  }, [isAnalyzing, mode, onAnalysisComplete, isQuotaExceeded, isPaused]);

  const handleManualCapture = async () => {
    if (isQuotaExceeded) {
       setError("API Limit erreicht. Bitte warten.");
       return;
    }

    if (videoRef.current && canvasRef.current && !isAnalyzing) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        
        setIsAnalyzing(true);
        setError(null);
        setIsDuplicateScan(false);
        
        try {
          const result = await analyzeImage(dataUrl);
          if (result.item_detected) {
            handleScanSuccess(result, dataUrl, true);
          } else {
            setError("Kein Objekt erkannt.");
            setTimeout(() => setError(null), 3000);
          }
        } catch (err: any) {
          const errStr = JSON.stringify(err) + (err.message || "");
          if (errStr.includes("429") || errStr.includes("RESOURCE_EXHAUSTED")) {
             setIsQuotaExceeded(true);
             setIsPaused(true);
             setError("⚠️ API-Limit erreicht.");
          } else {
             setError("Fehler bei der Analyse.");
             setTimeout(() => setError(null), 3000);
          }
        } finally {
          setIsAnalyzing(false);
        }
      }
    }
  };

  const speakResult = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'de-DE';
      utterance.rate = 1.1;
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setImage(result);
        setError(null);
        handleAnalyze(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async (imgToAnalyze?: string) => {
    const targetImage = imgToAnalyze || image;
    if (!targetImage) return;

    setIsAnalyzing(true);
    setError(null);

    try {
      const result = await analyzeImage(targetImage);
      onAnalysisComplete(result, targetImage);
    } catch (err: any) {
      const errStr = JSON.stringify(err) + (err.message || "");
      if (errStr.includes("429") || errStr.includes("RESOURCE_EXHAUSTED")) {
          setError("⚠️ API-Limit erreicht.");
          setIsQuotaExceeded(true);
      } else {
          setError("Fehler bei der Analyse.");
      }
    } finally {
      setIsAnalyzing(false);
    }
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  const resetScanner = () => {
    setImage(null);
    setError(null);
    setIsAnalyzing(false);
    setLastScannedResult(null);
    if (mode === 'camera') startCamera();
  };

  return (
    <div className={`flex flex-col h-full bg-white dark:bg-slate-900 rounded-xl shadow-sm overflow-hidden animate-fade-in relative transition-colors ${isEmbedded ? 'rounded-3xl' : ''}`}>
      {!isEmbedded && (
        <div className="p-4 border-b dark:border-slate-800 flex justify-between items-center bg-slate-900 text-white z-10">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            {mode === 'camera' ? <Camera className="w-5 h-5" /> : <Upload className="w-5 h-5" />}
            {mode === 'camera' ? 'Live Scanner' : 'Foto Upload'}
          </h2>
          <div className="flex gap-2">
            <button 
              onClick={() => setMode(mode === 'camera' ? 'upload' : 'camera')}
              className="text-slate-300 hover:text-white mr-2"
              title="Modus wechseln"
            >
              {mode === 'camera' ? <ImageIcon className="w-6 h-6" /> : <SwitchCamera className="w-6 h-6" />}
            </button>
            <button onClick={onCancel} className="text-slate-400 hover:text-white">
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>
      )}

      {/* Embedded Header Controls */}
      {isEmbedded && (
         <div className="absolute top-4 right-4 z-20 flex gap-2">
             <div className={`backdrop-blur-md px-3 py-1 rounded-full text-xs font-medium flex items-center gap-2 border border-white/10 transition-colors ${
                 isQuotaExceeded ? 'bg-red-500/80 text-white' : 
                 isPaused ? 'bg-amber-500/80 text-white' : 
                 'bg-black/40 text-white'
             }`}>
                {isQuotaExceeded ? (
                   <>
                     <AlertCircle className="w-3 h-3" />
                     Limit erreicht
                   </>
                ) : isPaused ? (
                   <>
                     <Pause className="w-3 h-3" />
                     Pausiert
                   </>
                ) : isAnalyzing ? (
                   <>
                     <Loader2 className="w-3 h-3 animate-spin text-blue-400" />
                     Analysiere...
                   </>
                ) : mode === 'camera' ? (
                   <>
                     <span className="relative flex h-2 w-2">
                       <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                       <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                     </span>
                     Auto-Scan
                   </>
                ) : 'Upload Modus'}
             </div>
             
             {/* Power/Pause Button - Disconnect Feature */}
             {mode === 'camera' && (
                 <button 
                    onClick={togglePause}
                    className={`backdrop-blur-md p-2 rounded-full transition-colors border border-white/10 ${
                        isPaused || isQuotaExceeded ? 'bg-white text-slate-900 hover:bg-slate-200' : 'bg-black/40 text-white hover:bg-black/60'
                    }`}
                    title={isPaused ? "Scanner starten" : "Scanner pausieren"}
                 >
                    {isPaused || isQuotaExceeded ? <Play className="w-4 h-4 fill-current" /> : <Power className="w-4 h-4" />}
                 </button>
             )}

             <button 
                onClick={() => setMode(mode === 'camera' ? 'upload' : 'camera')}
                className="bg-black/40 backdrop-blur-md p-2 rounded-full text-white hover:bg-black/60 transition-colors border border-white/10"
                title="Modus wechseln"
             >
                {mode === 'camera' ? <ImageIcon className="w-4 h-4" /> : <SwitchCamera className="w-4 h-4" />}
             </button>
         </div>
      )}

      <div className="flex-1 bg-slate-900 relative flex flex-col items-center justify-center overflow-hidden">
        
        {/* Paused State */}
        {(isPaused || isQuotaExceeded) && mode === 'camera' && !image && (
             <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900 z-10 text-white p-6 text-center animate-fade-in">
                 <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 ${isQuotaExceeded ? 'bg-red-500/20 text-red-500' : 'bg-slate-800 text-slate-400'}`}>
                     <Power className="w-10 h-10" />
                 </div>
                 <h3 className="text-xl font-bold mb-2">
                     {isQuotaExceeded ? 'API Limit erreicht' : 'Scanner ist aus'}
                 </h3>
                 <p className="text-slate-400 mb-6 max-w-xs">
                     {isQuotaExceeded 
                        ? 'Bitte warte einen Moment, bevor du fortfährst.' 
                        : 'Klicke auf Start, um den Live-Scanner zu aktivieren.'}
                 </p>
                 <button 
                    onClick={togglePause}
                    className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-full font-bold flex items-center gap-2 transition-transform active:scale-95"
                 >
                    <RefreshCw className="w-4 h-4" />
                    {isQuotaExceeded ? 'Verbindung testen' : 'Scanner starten'}
                 </button>
             </div>
        )}

        {/* Camera View */}
        {mode === 'camera' && !image && !isPaused && !isQuotaExceeded && (
          <div className="absolute inset-0 w-full h-full flex items-center justify-center bg-black">
             <video 
               ref={videoRef} 
               autoPlay 
               playsInline 
               muted 
               className="w-full h-full object-cover opacity-90"
               onLoadedMetadata={() => {
                 if(videoRef.current) videoRef.current.play();
               }}
             />
             <canvas ref={canvasRef} className="hidden" />
             
             {/* Radar Scanning Effect */}
             {!isAnalyzing && (
               <div className="absolute inset-0 pointer-events-none overflow-hidden">
                  <div className="absolute inset-0 border-2 border-blue-500/30 rounded-lg m-4"></div>
                  {/* Scanning Line */}
                  <div className="absolute w-full h-1 bg-gradient-to-r from-transparent via-blue-500 to-transparent opacity-50 top-0 animate-[scan_5s_ease-in-out_infinite]"></div>
                  
                  {/* Crosshairs */}
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 border border-white/20 rounded-full flex items-center justify-center">
                      <div className="w-60 h-60 border border-white/10 rounded-full animate-ping opacity-20"></div>
                      <ScanLine className="w-8 h-8 text-white/50 animate-pulse" />
                  </div>

                  {/* Duplicate Notification */}
                  {isDuplicateScan && (
                      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 mt-32 bg-amber-500/90 text-white px-4 py-2 rounded-full text-sm font-bold backdrop-blur-md animate-fade-in flex items-center gap-2 shadow-lg">
                          <CopyCheck className="w-4 h-4" /> Bereits erfasst
                      </div>
                  )}
               </div>
             )}

             {/* Manual Trigger Button */}
             <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-50 flex flex-col items-center gap-2">
                <button 
                  onClick={handleManualCapture}
                  disabled={isAnalyzing}
                  className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full border-4 border-white flex items-center justify-center hover:bg-white/30 transition-all active:scale-95 shadow-2xl disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                  aria-label="Scan starten"
                >
                   <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center relative pointer-events-none">
                      {isAnalyzing ? (
                        <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
                      ) : (
                        <div className="w-14 h-14 bg-white border-2 border-slate-300 rounded-full transition-transform hover:scale-95"></div>
                      )}
                   </div>
                </button>
                <span className="text-white/90 text-xs font-medium bg-black/50 px-3 py-1 rounded-full backdrop-blur-md">
                   {isAnalyzing ? 'Analysiere...' : 'Scan'}
                </span>
             </div>

             <div className="absolute top-4 left-4 text-white px-3 py-1 rounded-full text-xs backdrop-blur-md flex items-center gap-2 border border-white/10 bg-black/50">
                <Radio className="w-3 h-3 text-red-500 animate-pulse" />
                REC
             </div>
             
             {/* Error Toast */}
             {error && (
               <div className="absolute top-20 left-1/2 transform -translate-x-1/2 bg-red-500/90 text-white px-4 py-2 rounded-full text-sm font-medium backdrop-blur-md animate-fade-in flex items-center gap-2 shadow-lg z-50 w-max max-w-[90%] text-center">
                  <AlertCircle className="w-4 h-4 shrink-0" /> {error}
               </div>
             )}
          </div>
        )}

        {/* Upload Mode UI */}
        {mode === 'upload' && !image && (
          <div className="bg-slate-50 dark:bg-slate-900 w-full h-full flex flex-col items-center justify-center p-6">
            <div 
              onClick={triggerFileSelect}
              className="border-3 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl p-12 hover:border-blue-500 dark:hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-slate-800 transition-all cursor-pointer group text-center max-w-md w-full"
            >
              <div className="w-20 h-20 bg-blue-100 dark:bg-slate-800 text-blue-600 dark:text-blue-400 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Upload className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-medium text-slate-800 dark:text-white mb-2">Foto auswählen</h3>
              <p className="text-slate-500 dark:text-slate-400">Tippe hier für Galerie</p>
            </div>
            <input 
              type="file" 
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />
          </div>
        )}

        {/* Preview / Analysis Overlay */}
        {image && (
          <div className="absolute inset-0 bg-slate-900 z-30 flex flex-col">
             <div className="flex-1 relative overflow-hidden">
                <img src={image} alt="Capture" className="w-full h-full object-cover bg-black/50 backdrop-blur-xl opacity-50" />
                
                {/* Analyzing Overlay */}
                {isAnalyzing && (
                  <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center text-white z-40">
                    <div className="relative">
                      <div className="absolute inset-0 bg-blue-500 blur-xl opacity-20 animate-pulse"></div>
                      <Loader2 className="w-16 h-16 animate-spin text-blue-400 relative z-10" />
                    </div>
                    <p className="mt-6 text-xl font-light tracking-wide">Analysiere Objekt...</p>
                  </div>
                )}

                {/* Success Overlay for Camera Mode */}
                {!isAnalyzing && mode === 'camera' && lastScannedResult && (
                   <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-black/70 backdrop-blur-md p-6 text-center animate-fade-in">
                       <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mb-6 shadow-2xl shadow-green-500/40 animate-bounce">
                           <Check className="w-10 h-10 text-white" />
                       </div>
                       <h3 className="text-2xl font-bold text-white mb-2 tracking-tight">{lastScannedResult.title}</h3>
                       <p className="text-4xl font-black text-blue-400 mb-8">{lastScannedResult.price_estimate}</p>
                       
                       <p className="text-sm text-slate-400 font-medium bg-black/30 px-4 py-2 rounded-full mb-8">
                         Wurde im Verlauf gespeichert
                       </p>

                       <div className="w-48 bg-slate-700/50 rounded-full h-1.5 overflow-hidden">
                           <div className="h-full bg-white animate-[width_4s_linear] w-full origin-left transform" style={{animationDuration: '4s', animationName: 'shrink'}}></div>
                       </div>
                       <style>{`
                          @keyframes shrink {
                            from { width: 100%; }
                            to { width: 0%; }
                          }
                       `}</style>
                   </div>
                )}
             </div>

             {/* Action Bar for Preview (Only visible if upload mode) */}
             {!isAnalyzing && mode === 'upload' && (
                <div className="p-6 bg-white dark:bg-slate-900 flex flex-col gap-4 relative z-50">
                   {error && (
                     <div className="bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 p-3 rounded-lg text-sm flex gap-2">
                       <AlertCircle className="w-5 h-5" /> {error}
                     </div>
                   )}
                   <button
                     onClick={() => handleAnalyze()}
                     className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-lg flex items-center justify-center gap-2 shadow-lg shadow-blue-200 dark:shadow-blue-900/30"
                   >
                     <Sparkles className="w-5 h-5" />
                     Jetzt Bewerten
                   </button>
                   <button
                     onClick={resetScanner}
                     className="w-full py-3 text-slate-500 dark:text-slate-400 font-medium hover:text-slate-800 dark:hover:text-white flex items-center justify-center gap-2"
                   >
                     <RefreshCw className="w-4 h-4" />
                     Neues Foto
                   </button>
                </div>
             )}
          </div>
        )}
      </div>
      
      <style>{`
        @keyframes scan {
          0% { top: 0%; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
      `}</style>
    </div>
  );
};

export default Scanner;